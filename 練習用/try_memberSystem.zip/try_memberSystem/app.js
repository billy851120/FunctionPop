var express = require('express');
var app = express();
var port = '5002';
app.listen(port, console.log(`https://localhost:${port}`))


var userController = require('./controller/userController');
var commentController = require('./controller/commentController');
var bp = require('body-parser');
var session = require('express-session');
var flash = require('connect-flash');
var moment = require('moment');
var shortDataFormat = 'YYYY-MM-DD hh:mm:ss';


function redirectBack(req, res, next) {
    res.redirect('back');
}

app.use(bp.urlencoded({ extended: false }));
app.use(bp.json());
app.use(session({ secret: 'keyboard cat', resave: false, saveUninitialized: true }));
app.use(flash());
app.use((req, res, next) => {
    res.locals.isLogin = req.session.isLogin;
    res.locals.username = req.session.username;
    res.locals.nickname = req.session.nickname;
    res.locals.errorMessage = req.flash('errorMessage');
    // 將 moment 和 shortDateFormat 放到 locals 全域環境中
    res.locals.moment = moment;
    res.locals.shortDataFormat = shortDataFormat;
    next();
});


app.set('view engine', 'ejs');

app.get('/login', userController.login);
app.post('/login', userController.handleLogin, redirectBack);
app.get('/logout', userController.logout);
app.get('/', commentController.index);
app.get('/register', userController.register);
app.post('/register', userController.handleRegister, redirectBack);
app.post('/comments', commentController.add, redirectBack);
app.get('/delete_comments/:id', commentController.delete);
app.get('/update_comments/:id', commentController.update);
app.post('/update_comments/:id', commentController.handleupdate);

