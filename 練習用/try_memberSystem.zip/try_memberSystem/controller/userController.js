// 引入 userModel
var userModel = require('../models/userModel');
var bcrypt = require('bcrypt');
var saltRounds = 10; // 增加密碼複雜程度

var userController = {
    login: (req, res) => {
        res.render('login');
    },

    // 驗證登入狀態
    handleLogin: (req, res, next) => {
        var { username, password } = req.body;
        // console.log(`username:${username}`);
        // 確認是否有填入資料
        if (!username || !password) {
            req.flash('errorMessage', '請輸入您的帳密！');
            return next();
        }
        userModel.get(username, password, (err, user) => {
            console.log(`UC get_user ${user}`);
            if (err) {
                req.flash('errorMessage', err.toString());
                return next();
            }
            if (!user) {
                req.flash('errorMessage', '使用者不存在');
                return next();
            }
            // 驗證密碼是否正確，三個參數代表: 明碼, 雜湊密碼, 方法
            bcrypt.compare(password, user.password, (err, isSuccess) => {
                if (err || !isSuccess) {
                    req.flash('errorMessage', '密碼錯誤');
                    return next();
                }
                req.session.username = user.username;
                req.session.nickname = user.nickname;

                res.redirect('/');
            });
        })
    },
    logout: (req, res) => {
        // req.session.isLogin = false;
        // 登出就把 session 重置
        req.session.username = null;
        req.session.nickname = null;
        res.redirect('/');
    },
    register: (req, res) => {
        // 把路徑放在 user 資料夾，比較方便管理
        res.render('user/register');
    },
    handleRegister: (req, res, next) => {
        // 從 resquest body 拿取 user 資料
        var { username, password, nickname } = req.body;
        console.log(`username:${username},password:${password},nickname:${nickname}`);
        if (!username || !password || !nickname) {
            // 這裡用 return 就可避免 if-else 寫法增加層數
            req.flash('errorMessage', '缺少必要欄位');
            return next();
        }
        bcrypt.hash(password, saltRounds, (err, hash) => {
            if (err) {
                req.flash('errorMessage', err.toString());
                return next();
            }

            userModel.add({ username, password: hash, nickname }, (err, results) => {
                if (err) {
                    req.flash('errorMessage', '已存在相同用戶名');
                    return next();
                }
                // 註冊成功就保持登入狀態，並導回首頁
                req.session.username = username;
                req.session.nickname = nickname;
                res.redirect('/');
            });
        });
    }
}

// 輸出 userController
module.exports = userController;