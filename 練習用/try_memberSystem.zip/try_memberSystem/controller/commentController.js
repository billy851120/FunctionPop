const { destroy } = require('../db');
var commentModel = require('../models/commentModel');

var commentController = {
    add: (req, res, next) => {
        var username = req.session.username;
        var { content } = req.body;
        console.log(`username : ${username}`);
        console.log(`req.body.content : ${req.body.content} `)
        if (!username) {
            req.flash('errorMessage', '請先登入');
            return next();
        }
        if (!content) {
            req.flash('errorMessage', '缺少必要欄位');
            return next();
        }
        // 若新增失敗就導回首頁
        commentModel.add({ username, content }, err => {
            return res.redirect('/');
        });

    },

    index: (req, res) => {
        commentModel.getAll((err, result) => {
            if (err) {
                console.log(err);
            }
            // console.log(result);
            res.render('index', {
                comments: result
            })

        })
    },

    delete: (req, res) => {
        // 除了網址列上的 id，也需傳入 session 以確認是否為該 comment 作者
        console.log('params_id_is');
        console.log(req.params.id);
        commentModel.delete(req.session.username, req.params.id, err => {
            res.redirect('/');
        })
    },

    update: (req, res) => {
        commentModel.get(req.params.id, (err, result) => {
            console.log(res.locals.username);
            res.render('update', {
                comment: result[0]
            });
        })
    },
    handleupdate: (req, res) => {
        var { changeComment } = req.body;
        var { id } = req.params;
        commentModel.handleupdate({ changeComment, id }, (err, result) => {
            res.redirect('/');
        })
    }
}

module.exports = commentController;