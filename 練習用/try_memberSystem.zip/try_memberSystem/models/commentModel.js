var db = require('../db');

var commentModel = {
    // 新增 comment 功能
    add: ({ username, content }, cb) => {
        // comment = content;
        db.query('insert into comments(username,comment) values (?,?)',
            [username, content],
            (err, result) => {
                if (err) return cb(err);
                cb(null);
            });
    },

    // 讀取 comment 功能
    getAll: (cb) => {
        db.query(
            'select C.id,c.username,U.nickname,U.created_at,C.comment,C.created_at from comments as C left join users as U on U.username = C.username',
            (err, result) => {
                // console.log(result);
                if (err) return cb(err);
                cb(null, result);
            });
    },

    delete: (username, id, cb) => {
        db.query(
            'delete from comments where id = ? and username = ? ',
            [id, username],
            (err, result) => {
                if (err) return cb(err);
                cb(null);
            }
        )
    },

    get: (id, cb) => {
        db.query(
            'select C.username,C.comment,C.id,U.nickname from comments as C left join users as U on U.username = C.username where C.id = ? ',
            [id],
            (err, result) => {
                if (err) return cb(err);
                cb(null, result);
            }
        )
    },
    handleupdate: ({ changeComment, id }, cb) => {
        db.query(
            'update comments set comment = ? where id = ?',
            [changeComment, id],
            (err, result) => {
                // console.log('id');
                // console.log(id);
                // console.log('changeComment');
                // console.log(changeComment);
                if (err) return cb(err);
                cb(null)
            }
        )
    }

}

module.exports = commentModel;