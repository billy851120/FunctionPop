var db = require('../db');

var userModel = {
    //新增user功能
    add: (user, cb) => {
        db.query('insert into users(username,password,nickname) values(?,?,?)',
            [user.username, user.password, user.nickname],
            (err, results) => {
                if (err) return cb(err);
                cb(null);
            });
    },
    // 登入 -> 讀取 user 功能
    get: (username, password, cb) => {
        db.query('select * from users where username = ?', [username], (err, results) => {
            // console.log(`results : ${results[0]}`);
            // console.log(`password : ${results[0].password}`);
            if (err) return cb(err);

            cb(null, results[0]);
        });
    }
}

module.exports = userModel;